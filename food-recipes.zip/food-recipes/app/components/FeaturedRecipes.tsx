'use client'

import { useState, useEffect } from 'react'
import Image from 'next/image'
import { ChevronLeft, ChevronRight } from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'

const featuredRecipes = [
  { id: 1, title: 'Spicy Chicken Tacos', query: 'tacos' },
  { id: 2, title: 'Vegetarian Pizza', query: 'pizza' },
  { id: 3, title: 'Chocolate Lava Cake', query: 'chocolate+cake' },
]

export default function FeaturedRecipes() {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [images, setImages] = useState<string[]>([])

  useEffect(() => {
    const fetchImages = async () => {
      const imagePromises = featuredRecipes.map(recipe =>
        fetch(`https://source.unsplash.com/featured/?${recipe.query}&food`)
          .then(response => response.url)
      )
      const fetchedImages = await Promise.all(imagePromises)
      setImages(fetchedImages)
    }

    fetchImages()
  }, [])

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentIndex((prevIndex) =>
        prevIndex === featuredRecipes.length - 1 ? 0 : prevIndex + 1
      )
    }, 5000)

    return () => clearInterval(timer)
  }, [])

  const nextSlide = () => {
    setCurrentIndex((prevIndex) =>
      prevIndex === featuredRecipes.length - 1 ? 0 : prevIndex + 1
    )
  }

  const prevSlide = () => {
    setCurrentIndex((prevIndex) =>
      prevIndex === 0 ? featuredRecipes.length - 1 : prevIndex - 1
    )
  }

  return (
    <div className="relative w-full h-[500px] overflow-hidden rounded-lg shadow-lg">
      <AnimatePresence initial={false} custom={currentIndex}>
        {images.length > 0 && (
          <motion.div
            key={currentIndex}
            custom={currentIndex}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5 }}
            className="absolute inset-0"
          >
            <Image
              src={images[currentIndex]}
              alt={featuredRecipes[currentIndex].title}
              fill
              className="object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent" />
            <div className="absolute bottom-0 left-0 right-0 p-8">
              <h2 className="text-white text-4xl font-bold mb-4">{featuredRecipes[currentIndex].title}</h2>
              <button className="bg-green-600 text-white px-6 py-2 rounded-full hover:bg-green-700 transition-colors">
                View Recipe
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      <button
        onClick={prevSlide}
        className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-white bg-opacity-50 rounded-full p-2 hover:bg-opacity-75 transition-all"
      >
        <ChevronLeft size={24} />
      </button>
      <button
        onClick={nextSlide}
        className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-white bg-opacity-50 rounded-full p-2 hover:bg-opacity-75 transition-all"
      >
        <ChevronRight size={24} />
      </button>
    </div>
  )
}

