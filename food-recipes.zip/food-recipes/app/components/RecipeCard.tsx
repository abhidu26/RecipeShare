'use client'

import Image from 'next/image'
import Link from 'next/link'
import { motion } from 'framer-motion'
import { Clock, Users } from 'lucide-react'

export default function RecipeCard({ recipe }) {
  return (
    <motion.div
      whileHover={{ scale: 1.03 }}
      className="bg-white rounded-lg shadow-lg overflow-hidden recipe-card-transition"
    >
      <Link href={`/recipes/${recipe.id}`}>
        <div className="relative h-48">
          {recipe.image && (
            <Image
              src={recipe.image}
              alt={recipe.title}
              fill
              className="object-cover"
            />
          )}
        </div>
        <div className="p-6">
          <h3 className="text-xl font-semibold mb-2">{recipe.title}</h3>
          <p className="text-gray-600 mb-4">{recipe.description}</p>
          <div className="flex justify-between text-sm text-gray-500">
            <div className="flex items-center">
              <Clock size={16} className="mr-1" />
              <span>{recipe.cookTime} mins</span>
            </div>
            <div className="flex items-center">
              <Users size={16} className="mr-1" />
              <span>{recipe.servings} servings</span>
            </div>
          </div>
        </div>
      </Link>
    </motion.div>
  )
}

