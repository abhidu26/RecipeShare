'use client'

import { useState, useEffect } from 'react'
import RecipeCard from './RecipeCard'

const recipes = [
  { 
    id: 1, 
    title: 'Classic Margherita Pizza', 
    query: 'pizza', 
    description: 'A simple yet delicious pizza with fresh mozzarella, tomatoes, and basil.',
    cookTime: 30,
    servings: 4
  },
  { 
    id: 2, 
    title: 'Creamy Mushroom Risotto', 
    query: 'risotto', 
    description: 'A comforting Italian rice dish with savory mushrooms and Parmesan cheese.',
    cookTime: 45,
    servings: 6
  },
  { 
    id: 3, 
    title: 'Grilled Salmon with Lemon Butter', 
    query: 'salmon', 
    description: 'Perfectly grilled salmon fillet with a zesty lemon butter sauce.',
    cookTime: 25,
    servings: 2
  },
  { 
    id: 4, 
    title: 'Chocolate Chip Cookies', 
    query: 'cookies', 
    description: 'Classic homemade cookies with gooey chocolate chips and a soft center.',
    cookTime: 20,
    servings: 24
  },
]

export default function RecipeList() {
  const [images, setImages] = useState<string[]>([])

  useEffect(() => {
    const fetchImages = async () => {
      const imagePromises = recipes.map(recipe =>
        fetch(`https://source.unsplash.com/featured/?${recipe.query}&food`)
          .then(response => response.url)
      )
      const fetchedImages = await Promise.all(imagePromises)
      setImages(fetchedImages)
    }

    fetchImages()
  }, [])

  return (
    <div>
      <h2 className="text-3xl font-bold mb-6">Latest Recipes</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {recipes.map((recipe, index) => (
          <RecipeCard key={recipe.id} recipe={{...recipe, image: images[index] || ''}} />
        ))}
      </div>
    </div>
  )
}

