import FeaturedRecipes from './components/FeaturedRecipes'
import RecipeList from './components/RecipeList'

export default function Home() {
  return (
    <div className="space-y-8">
      <h1 className="text-4xl font-bold text-center mb-8">Welcome to Tasty Recipes</h1>
      <FeaturedRecipes />
      <RecipeList />
    </div>
  )
}

