'use client'

import { useState, useEffect } from 'react'
import Image from 'next/image'
import { motion } from 'framer-motion'
import { Clock, Users, ChefHat } from 'lucide-react'

const recipes = [
  {
    id: 1,
    title: 'Classic Margherita Pizza',
    query: 'pizza',
    description: 'A simple yet delicious pizza with fresh mozzarella, tomatoes, and basil.',
    cookTime: 30,
    servings: 4,
    ingredients: [
      '1 pizza dough',
      '1/2 cup tomato sauce',
      '8 oz fresh mozzarella, sliced',
      '1/4 cup fresh basil leaves',
      '2 tbsp olive oil',
      'Salt and pepper to taste',
    ],
    instructions: [
      'Preheat the oven to 450°F (230°C).',
      'Roll out the pizza dough on a floured surface.',
      'Spread tomato sauce evenly over the dough.',
      'Add sliced mozzarella and season with salt and pepper.',
      'Bake for 12-15 minutes or until the crust is golden brown.',
      'Remove from the oven and top with fresh basil leaves.',
      'Drizzle with olive oil before serving.',
    ],
  },
]

export default function RecipePage({ params }) {
  const [servings, setServings] = useState(4)
  const [image, setImage] = useState('')
  const recipe = recipes.find((r) => r.id === parseInt(params.id))

  useEffect(() => {
    if (recipe) {
      fetch(`https://source.unsplash.com/featured/?${recipe.query}&food`)
        .then(response => setImage(response.url))
    }
  }, [recipe])

  if (!recipe) {
    return <div>Recipe not found</div>
  }

  const adjustedIngredients = recipe.ingredients.map(ingredient => {
    const [amount, ...rest] = ingredient.split(' ')
    const newAmount = parseFloat(amount) * (servings / recipe.servings)
    return `${newAmount.toFixed(2)} ${rest.join(' ')}`
  })

  return (
    <div className="max-w-4xl mx-auto">
      <motion.h1 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="text-4xl font-bold mb-6"
      >
        {recipe.title}
      </motion.h1>
      <div className="relative w-full h-[400px] mb-8">
        {image && (
          <Image
            src={image}
            alt={recipe.title}
            fill
            className="object-cover rounded-lg"
          />
        )}
      </div>
      <motion.p 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.2, duration: 0.5 }}
        className="text-xl mb-6"
      >
        {recipe.description}
      </motion.p>
      <div className="grid md:grid-cols-3 gap-4 mb-8">
        <div className="flex items-center justify-center p-4 bg-green-100 rounded-lg">
          <Clock className="mr-2" />
          <span>{recipe.cookTime} mins</span>
        </div>
        <div className="flex items-center justify-center p-4 bg-blue-100 rounded-lg">
          <Users className="mr-2" />
          <span>{servings} servings</span>
        </div>
        <div className="flex items-center justify-center p-4 bg-yellow-100 rounded-lg">
          <ChefHat className="mr-2" />
          <span>Intermediate</span>
        </div>
      </div>
      <div className="grid md:grid-cols-2 gap-8">
        <div>
          <h2 className="text-2xl font-semibold mb-4">Ingredients</h2>
          <div className="mb-4">
            <label htmlFor="servings" className="block text-sm font-medium text-gray-700 mb-2">
              Adjust servings:
            </label>
            <input
              type="number"
              id="servings"
              min="1"
              value={servings}
              onChange={(e) => setServings(parseInt(e.target.value))}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
            />
          </div>
          <ul className="list-disc pl-6">
            {adjustedIngredients.map((ingredient, index) => (
              <li key={index} className="mb-2">{ingredient}</li>
            ))}
          </ul>
        </div>
        <div>
          <h2 className="text-2xl font-semibold mb-4">Instructions</h2>
          <ol className="list-decimal pl-6">
            {recipe.instructions.map((instruction, index) => (
              <motion.li 
                key={index} 
                className="mb-4"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1, duration: 0.5 }}
              >
                {instruction}
              </motion.li>
            ))}
          </ol>
        </div>
      </div>
    </div>
  )
}

