import './globals.css'
import { Playfair_Display, Lato } from 'next/font/google'
import Header from './components/Header'
import Footer from './components/Footer'

const playfair = Playfair_Display({ subsets: ['latin'], variable: '--font-playfair' })
const lato = Lato({ subsets: ['latin'], weight: ['400', '700'], variable: '--font-lato' })

export const metadata = {
  title: 'Tasty Recipes',
  description: 'Discover and share delicious recipes',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={`${playfair.variable} ${lato.variable} font-sans`}>
        <Header />
        <main className="min-h-screen p-4 md:p-8 bg-amber-50">
          {children}
        </main>
        <Footer />
      </body>
    </html>
  )
}

